/*average of three numbers*/
#include <stdio.h>
void main()
{
int a;
int b;
int c;
float average;
a=7;
b=20;
c=30;
average=(a+b+c)/3;
printf("average is %f",average);
}
