#include <stdio.h>

int main()
{
   int a[50],n,i,big,pos;
   printf("enter the size of array : ");
   scanf("%d",&n);
   for(i=0;i<n;i++)
   scanf("%d",&a[i]);
   for(i=0;i<n;i++)
   printf("%d",a[i]);
   printf("\n");
  big=a[0];pos=0;
  for(i=1;i<n;i++)
  {
      if(a[i]>big)
      {
          big=a[i];
          pos=i;
      }
  }
   printf("biggest is %d at position %d",big,pos);
}
