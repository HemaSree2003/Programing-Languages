#include <stdio.h>
#include<string.h>
int main()
{
    char str[20];
    int i=0;
    printf("enter string: ");
    scanf("%s",str);
    while(str[i]!=0)
    {
        printf("char at %d is %c \n",i,str[i]);
        i++;
    }
    return 0;
}