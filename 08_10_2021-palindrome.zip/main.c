#include<stdio.h>

int main()
{
    int n,n1,d,rev=0;
    printf("enter n value: ");
    scanf("%d",&n);
    n1=n;
    while(n1>0)
  {
      d=n1%10;
     rev=rev*10+d;
     n1=n1/10;
  }
    printf("given number is %d\n",n);
    printf("reverse of number is %d\n",rev);
    if(n=rev)
    printf("palindrome");
    else
    printf("not palindrome");
}


