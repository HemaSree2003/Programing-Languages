#include<stdio.h>
void main()
{
    char a,e,i,o,u;
       printf("enter alphabet : ");
       scanf("%c%c%c%c%c",&a,e,i,o,u);
    if (alphabet==a)
       printf("vowel");
    else if (alphabet==e)
       printf("vowel");
    else if (alphabet==i)
       printf("vowel");
    else if (alphabet==o)
       printf("vowel");
    else if (alphabet==u)
       printf("vowel");
    else
       printf("consonent");
}