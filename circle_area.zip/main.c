#include <stdio.h>
void main()
{
    float r,area;
    r=7;
    area=3.14*r*r;
printf("area is %f",area);
}


