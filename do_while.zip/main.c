
#include <stdio.h>

int main()
{
    int i=10;
  
    do
    {
        printf("%d\n",i);
        i=i-1;
    }
    while(i>0);
    { 
        printf("%d\t",i);
    }
    return 0;
}
