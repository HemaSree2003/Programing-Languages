
#include <stdio.h>

int main()
{
    int i,j,temp;
    printf("Enter two numbers : ");
    scanf("%d%d",&i,&j);
    temp=i;
    i=j;
    j=temp;
    printf("The swapped numbers is %d and %d",i,j);
    return 0;
}
