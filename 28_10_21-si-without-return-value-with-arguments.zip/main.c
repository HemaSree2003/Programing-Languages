#include <stdio.h>
void si(int,int,int);
int main()
{
   int p,t,r;
  
  printf("enter p,t,r value : ");
  scanf("%d%d%d",&p,&t,&r); 
  si(p,t,r);
   return 0;
}
void si(int x,int y,int z)
{
  float si;
  si=x*y*z/100;
  printf("si is %f",si);
}