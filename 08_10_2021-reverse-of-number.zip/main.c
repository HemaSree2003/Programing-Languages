#include <stdio.h>

int main()
{
    int n,n1,d,rev=0;
    printf("enter n value");
    scanf("%d",&n);
    n1=n;
    while(n>0)
  {
      d=n%10;
      rev=rev*10+d;
      n=n/10;
  }
    printf("reverse of number is %d\n",rev);
    return 0;
}
