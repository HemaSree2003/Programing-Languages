#include<stdio.h>
void main()
{
    char ch[20];
    printf("Enter the string : ");
    gets(ch);
    printf("Final string : ");
    puts(ch);
}