
#include <stdio.h>

int main()
{
    int i=1,n;
    printf("enter n value : ");
    scanf("%d",&n);
    while(i<=n)
  {
      if(i%2==0)
      printf(" even number is %d\n",i);
      i++;
  }

    return 0;
}
