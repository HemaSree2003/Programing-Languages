
#include <stdio.h>

int main()
{
    int n,count=0,i;
    printf("enter n value : ");
    scanf("%d",&n);
    i=1;
    while(i<=n)
    {
        if(n%i==0)
        count++;
        i++;
    } 
        if(count==2)
        printf("prime number");
        else
        printf("not prime number");
    return 0;
}
