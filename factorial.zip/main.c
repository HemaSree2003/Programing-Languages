
#include <stdio.h>

int main()
{
    int i,n,prod=1;
    printf("enter n value : ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    prod=prod*i;
    printf("factorial of %d is %d",n,prod);
    return 0;
}
