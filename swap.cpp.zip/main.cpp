
#include <iostream>

using namespace std;

int main()
{
    int a,b,t;
    cout<<"enter two numbers:";
    cin>>a>>b;
    cout<<"before swapping:"<<a<<","<<b<<endl;
    t=a;
    a=b;
    b=t;
    cout<<"after swapping:"<<a<<","<<b;

    return 0;
}