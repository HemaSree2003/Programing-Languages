class B{
    void factorial(int x)
    {
        int fact=1;
        if(x>0)
        {
            for(int i=1;i<=x;i++)
            {
                fact=fact*i;
            }
        }
        else{
            fact=1;
        }
       System.out.println(fact);
        int r,count=0,n;
        n=fact;
       while(n>0)
        {
             r=n%10;
             if(r==0)
             {
                count++;
              }
             n=n/10;
        }
            System.out.println("count is"+count);
        }
       
        
    }

class Main{
    public static void main(String args[])
    {
        B ob=new B();
        ob.factorial(10);
    }
}