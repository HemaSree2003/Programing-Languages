#include<stdio.h>
int main()
{
    char s1[10],s2[10],s3[10];
    int i,j,k,len1=0,len2=0,len3=0;
    printf("enter first string name : ");
    scanf("%s",s1);
    
    while(s1[i]!='\0')
    {
        len1++;
        i++;
    }
    printf("lenth of first string is %d",len1);
    printf("enter second string name : ");
    scanf("%s",s2);
    
    while(s2[j]!='\0')
    {
        len2++;
        j++;
    }
    printf("length of second string is %d",len2);
    while(s1[i]!='\0')
    { 
        s3[k]=s1[i];
        i++;
    }
    k=++i;
    j=0;
    while(s2[j]!='\0')
    {
       s3[k]=s2[j];
       j++;
       k++;
    }
       s3[++k]='\0';
    printf("third string name is %c%c",s1,s2);
}