#include <stdio.h>

int main()
{
    int n,d,sum=0,n1;
    printf("enter n value");
    scanf("%d",&n);
    n1=n;
    while(n1>0)
  {
      d=n1%10;
      sum=sum+d*d*d;
      n1=n1/10;
  }
       if(sum==n)
       printf("armstrong");
       else
       printf("not armstrong");
    return 0;
}


