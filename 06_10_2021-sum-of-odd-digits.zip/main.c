#include <stdio.h>

int main()
{
    int n,d,sum=0;
    printf("enter n value : ");
    scanf("%d",&n);
    while(n>0)
  {
    d=n%10;
    if(d%2==1)
    sum=sum+d;
    n=n/10;
  }
    printf("sum if digits is %d",sum);
}