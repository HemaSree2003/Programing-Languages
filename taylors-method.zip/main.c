#include<stdio.h>
#include<math.h>
int main()
{
    int n,k,i;float h,x0,y0,y1,y2,y3,y4,yk,xk;
    printf("This program demonstrates Taylor's series Method\n");
    printf("\nDE:y'=x^2+y^2\n");
    printf("\nspecify your initial condition x0 and y0:");
    scanf("%f%f",&x0,&y0);
    printf("\nIVP: y'=x^2+y^2,y(%.2f)=%.2f\n",x0,y0);
    printf("\nEnter step length h:");
    scanf("%f",&h);
    printf("\nEnter the number of steps n:");
    scanf("%d",&n);
    printf("\nk\txk\tyk\n");
    printf("%d\t%.2f\t%.4f\n",k,x0,y0);
    for(i=1,k=0;i<=n;i++)
    {
        y1=pow(x0,2)+(pow(y0,2));
        y2=(2*x0)+(2*y0*y1);
        y3=2+(2*y0*y2)+2*(pow(y1,2));
        y4=(2*y0*y3)+(6*y1*y2);
        yk=y0+h*y1+(h*h/2)*y2+(h*h*h/6)*y3+(h*h*h*h/24)*y4;
        x0=x0+h;
        k++;
        printf("%d\t%.2f\t%.4f\n",k,x0,yk);
        y0=yk;
    }
    return 0;
}
