
#include <stdio.h>

int main()
{
    int i,f1=0,f2=1,j,f3;
    for(i=1;i<=5;i++)
        printf("%d\t",i);
        
        printf("\n%d\t%d",f1,f2);
        
          for(j=1;j<=3;j++)
            {
                f3=f1+f2;
                f1=f2;
                f2=f3;
                printf("\t%d",f3);
                
            }
           
}
