#include<stdio.h>
void main()
{
    int i,n;
    printf("enter n value : ");
    scanf("%d",&n);
       for(i=1;i<=n;i++)
        {
          printf("%d",i);
        
          if (i%2==0)
            printf(" is even number\n");
          else
            printf(" is odd number\n");
            
        }
}

