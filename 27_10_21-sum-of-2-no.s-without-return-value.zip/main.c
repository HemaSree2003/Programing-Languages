
#include <stdio.h>
void sum(int,int);
int main()
{
    int x,y;
    printf("enter two values : ");
    scanf("%d%d",&x,&y);
    printf("in main\n");
    sum(x,y);
    printf("\n again back to main");
    return 0;
}
void sum(int x,int y)
{
int s;
s=x+y;
printf("sum is %d",s);
}