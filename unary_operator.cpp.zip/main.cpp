#include<iostream>
using namespace std;
class test{
    public:
    int n;
    test(int i)
    {
        n=i;
    }
    void operator ++()
    {
        n=n+1;
    }
    void print()
    {
        cout<<n;
    }
};
int main()
{
    test t(5);
    ++t;
    t.print();
    return 0;
}