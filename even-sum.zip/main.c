
#include <stdio.h>

int main()
{
    int i,n,even_sum=0;
    printf("enter n value");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    if(i%2==0)
    even_sum=even_sum+i;
    printf("sum is %d",even_sum);

    return 0;
}
