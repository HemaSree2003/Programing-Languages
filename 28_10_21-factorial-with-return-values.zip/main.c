
#include <stdio.h>
int fact(int);
int main()
{
    int n,res;
    printf("enter value of n : ");
    scanf("%d",&n);
    res=fact(n);
    
    printf("result is %d",res);
    return 0;
    
}
int fact(int x)
{
    int i,fact=1;
    for(i=1;i<=x;i++)
    fact=fact*i;
    return fact;
}
