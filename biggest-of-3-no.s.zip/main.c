
#include <stdio.h>

int main()
{
    int a,b,c;
    printf("enter three values");
    scanf("%d%d%d",&a,&b,&c);
    if(a>=b && a>=c)
    printf("biggest no. is %d",a);
    else 
    if(b>=c && b>=a)
    printf("biggest no. is %d",b);
    else
    printf("biggest no. is %d",c);
    return 0;
}
