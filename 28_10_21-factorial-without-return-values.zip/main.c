#include <stdio.h>
void fact(int);
int main()
{
    int i,n;
    
    printf("enter value of n : ");
    scanf("%d",&n);
    fact(n);
    return 0;
    
}
void fact(int x)
{
    int i, fact=1;
    for(i=1;i<=x;i++)
    fact=fact*i;
    printf("factorial is %d",fact);
}
