#include<iostream>
using namespace std;
template<class T>
struct chainNode
{
    T element;
    chainNode<T>*next;
    chainNode<T>*prev;
    chainNode()
    {
    }
    chainNode(const T &element)
    {
    this->element=element;
    }
    chainNode(const T &element,chainNode<T>*next,chainNode<T>*prev)
    {
    this->element=element;
    this->next=next;
    this->prev=prev;
    }
};
template<class T>
class dllchain
{
  public:
  dllchain();
  void insertBeg(const T &theElement);
  void insertEnd(const T &theElement);
  void insertPos(int theIndex,const T &theElement);
  void eraseBeg();
  void eraseEnd();
  void erasePos(int theIndex);
  void output();
  T get(int theIndex);
  int indexOf(const T& theElement)const;
  protected:
  chainNode<T>*firstNode,*lastNode;
  int listSize;
};
template<class T>
dllchain<T>::dllchain()
{
   firstNode=NULL;
   lastNode=NULL;
   listSize=0;
}
template<class T>
void dllchain<T>::insertEnd(const T &theElement)
{
   chainNode<T>*p=new chainNode<T>(theElement,NULL,lastNode);
   lastNode->next=p;
   lastNode=p;
   listSize++;
}
template<class T>
void dllchain<T>::insertBeg(const T &theElement)
{
   if(firstNode==NULL)
   {
   firstNode=new chainNode<T>(theElement,NULL,NULL);
   lastNode=firstNode;
   }
   else
   {
   chainNode<T>*p;
   p=new chainNode<T>(theElement,firstNode,NULL);
   firstNode->prev=p;
   firstNode=p;
   }
   listSize++;
}
template<class T >
void dllchain<T>::insertPos(int theIndex,const T &theElement)
{
   if(theIndex<1 || theIndex>listSize-1)
   cout<<"Invalid index\n";
   else
   {
   chainNode<T>*p=firstNode;
   for(int i=0;i<theIndex-1;i++)
   p=p->next;
   chainNode<T>*q=p->next;
   p->next=new chainNode<T>(theElement,p->next,q->prev);
   q->prev=p->next;
   listSize++;
   }
}
template<class T>
void dllchain<T>::eraseBeg()
{
   chainNode<T>*deleteNode=firstNode;
   firstNode=firstNode->next;
   firstNode->prev=NULL;
   delete deleteNode;
   listSize--;
}
template<class T>
void dllchain<T>::eraseEnd()
{
  chainNode<T>*deleteNode=lastNode;
  lastNode=lastNode->prev;
  lastNode->next=NULL;
  delete deleteNode;
  listSize--;
}
template<class T>
void dllchain<T>::erasePos(int theIndex)
{
   if(theIndex<1 || theIndex>listSize-2)
   cout<<"Invalid index\n";
   else
   {
   chainNode<T>*deleteNode,*q;
   chainNode<T>*p=firstNode;
   for(int i=0;i<theIndex-1;i++)
   p=p->next;
   deleteNode=p->next;
   q=deleteNode->next;
   p->next=p->next->next;
   q->prev=p;
   delete deleteNode;
   listSize--;
   }
}
template<class T>
T dllchain<T>::get(int theIndex)
{
  if(theIndex<0||theIndex>listSize)
   {
   cout<<"Index="<<theIndex<<"size="<<listSize<<"illegal index"<<endl;
   }
   
   else
   {
   chainNode<T>*currentNode=firstNode;
   for(int i=0;i<theIndex;i++)
   currentNode=currentNode->next;
   return currentNode->element;
   }
   return 0;
}
template<class T>
int dllchain<T>::indexOf(const T &theElement)const
{
   chainNode<T>*currentNode=firstNode;
   int index=0;
   while(currentNode!=NULL && currentNode->element!=theElement)
   {
      currentNode=currentNode->next;
      index++;
   }
   if(currentNode==NULL)
      return -1;
    else
      return index;
}
template<class T>
void dllchain<T>::output()
{
  for(chainNode<T>*current=firstNode;current!=NULL;current=current->next)\
  {
  cout<<"<-"<<current->element<<"->";
  }
  cout<<"endl";
}int main()
{
	dllchain<int>a;
	cout<<"1.Insert at beggining"<<endl<<"2.Insert at end"<<endl<<"3.Insert at a position"<<endl<<"4.Erase at beginnning" <<endl<<"5.Erase at end"<<endl<<"6.Erase at position"<<endl<<"7.Output"<<endl<<"8.index of"<<"9.get index"<<endl;
	char ch='y';
	while(ch=='y')
	{
		int choice,ele,index;
		cout<<"Your choice"<<endl;
		cin>>choice;
		switch(choice)
		{
			case 1:
		
		        cout<<"Enter element to insert at beginning :";
			cin>>ele;
			a.insertBeg(ele);
			break;
			case 2:
			cout<<"Enter element to insert at ending :";
			cin>>ele;
			a.insertEnd(ele);
			break;
			case 3:
			cout<<"Enter index to insert at a position: ";
			cin>>index;
			cout<<"Enter element to insert at a position :";
			cin>>ele;
			a.insertPos(index,ele);
			break;
			case 4:cout<<"Erase at beginning";
			a.eraseBeg();
			break;
			case 5:cout<<"Erase at end";
			a.eraseEnd();
			break;
			case 6:
			cout<<"Enter index to remove at a positon: ";
			cin>>index;
			a.erasePos(index);
			case 7:
			a.output();
			break;
			case 8:
			cout<<"Enter index: ";
            cin>>index;
            cout<<"Element at index "<<index<<"is "<<a.get(index)<<endl;
            break;
            case 9:
            cout<<"Enter elememt: ";
                  cin>>ele;
                  index=a.indexOf(ele);
                  if(index==-1)
                     cout<<"Element not found\n";
                  else
                    cout<<"element "<<ele<<"is at index "<<index<<endl;
                    break;
		}
		cout<<"Do you want to continue? If yes, enter y ";
		cin>>ch;
	}
	return 0;
}