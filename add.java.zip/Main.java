
public class Main
{
	public static void main(String[] args) {
	    int a=5,b=10,sum;
	    sum=a+b;
		System.out.println("Addition of "+a+" and "+b+" is "+sum);
	}
}
