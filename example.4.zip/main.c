#include <stdio.h>

int main()
{
    int i,j,k=1;
    for(i=6;i>=1;i--)
    {
      
           for(j=6;j>=i;j--)
           {
           printf("%d ",j);
       }
       printf("\n");
    }
        
}