
#include <stdio.h>

int main()
{
    char s1[15],s2[15];
    int i=0,len=0,pos;
    printf("enter the name : ");
    scanf("%s",s1);
    len=0;i=0;
    while(s1[i]!='\0')
    {
        len++;
        i++;
    }
    printf("\n length of the string is %d",len);
    len--;
    pos=0;
    while(len>=0)
    {
        printf("\n copying from %d to %d",len,pos);
        printf("\n");
        s2[pos]=s1[len];
        len--;
        pos++;
    }
    s2[++pos]="\0";
    printf("first string is %s\n",s1);
    printf("second string is %s\n",s2);
}
