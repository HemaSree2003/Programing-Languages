#include <stdio.h>
int sum(int,int);
int main()
{
    int x,y,res;
    printf("enter two values : ");
    scanf("%d%d",&x,&y);
    res=sum(x,y);
    printf("result is %d",res);
    
    return 0;
}
int sum(int x,int y)
{
int s;
s=x+y;
return s;
}

