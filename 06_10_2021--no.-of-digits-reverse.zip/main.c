
#include <stdio.h>

int main()
{
    int n,d;
    printf("enter n value");
    scanf("%d",&n);
    while(n>0)
  {
      d=n%10;
      printf("digit is %d\n",d);
      n=n/10;
  }

}
