
#include <stdio.h>

int main()
{   
    char n;
    printf("Enter any character : ");
    scanf("%c",&n);
    printf("ASCII value of %c is %d",n,n);
    return 0;
}
