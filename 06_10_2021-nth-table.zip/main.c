
#include <stdio.h>

int main()
{
    int i=1,n,prod=1;
    printf("enter n value : ");
    scanf("%d",&n);
    while(i<=n)
  {
      prod=prod*i;
     printf("%d*%d=%d\n",i,n,i*n);
      i++;
  }
      
}
