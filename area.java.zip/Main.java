
public class Main
{
	public static void main(String[] args) {
	    int l,b,a;
	    l=2;
	    b=4;
	    a=l*b;
		System.out.println("Area of rectangle is "+a);
	}
}
