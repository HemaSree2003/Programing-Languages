
#include <stdio.h>
float si(int,int,int);
int main()
{
   int p,t,r;
   float a;
   printf("enter values of p,t,r : ");
   scanf("%d%d%d",&p,&t,&r);
   a=si(p,t,r);
   printf("si is %f",a);
   return 0;
}
float si(int x,int y,int z)
{
    float si;
    si=x*y*z/100;
    return si;
}