
#include <stdio.h>
void main()
{
    int a;
       printf("enter the value : ");
       scanf("%d",&a);
    if (a%5==0&&a%11==0)
       printf("divisible");
    else
       printf("not divisible");
}

