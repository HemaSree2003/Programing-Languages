#include <stdio.h>
void fact();
int main()
{
    fact();
    return 0;
    
}
void fact()
{
    int i,fact=1,n;
    
    printf("enter value of n : ");
    scanf("%d",&n);
    
    for(i=1;i<=n;i++)
    fact=fact*i;
    printf("factorial is %d",fact);
}

