#include <stdio.h>
void main()
{
    int n;
    printf("take value of n : ");
    scanf("%d",&n);
    if(n%2==0)
    printf("even number");
    else
    printf("odd number");
}
