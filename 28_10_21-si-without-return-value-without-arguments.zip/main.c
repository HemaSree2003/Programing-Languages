
#include <stdio.h>
void si();
int main()
{
   si();
   return 0;
}
void si()
{
  int p,t,r;
  float si;
  printf("enter p,t,r value : ");
  scanf("%d%d%d",&p,&t,&r);
  si=p*t*r/100;
  printf("si is %f",si);
}