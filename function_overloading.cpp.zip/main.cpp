#include<iostream>
using namespace std;
int area(int);
int area(int,int);
float area(float);
float area(float,float);
int main()
{
    int s,l,b;
    float r,bd,ht;
    cout<<"Enter side of square";
    cin>>s;
    cout<<"enter length and base";
    cin>>l>>b;
    cout<<"Enter radius";
    cin>>r;
    cout<<"Enter breadth and height";
    cin>>bd>>ht;
    cout<<"area of square"<<area(s);
    cout<<"area of rectangle"<<area(l,b);
    cout<<"area of circle"<<area(r);
    cout<<"area of triangle"<<area(bd,ht);
}
    int area(int s)
    {
        return (s*s);
    }
    int area(int l,int b)
    {
        return (l*b);
    }
    float area(float r)
    {
        return (r*r);
    }
    float area(float bd,float ht)
    {
        return (1/2*bd*ht);
    }