#include<iostream>
using namespace std;
class complex
{
private:
int real,img;
public:
complex()
{
}
complex(int r,int i)
{
real=r;
img=i;
}
complex operator +(complex c)
{
complex t;
t.real=real+c.real;
t.img=img+c.img;
return(t);
}
void print()
{
cout<<real<<"+i"<<img;
}
};
int main()
{
complex c1(0,0),c2(5,3),c3(7,2);
c1=c2+c3;
c1.print();
}







