#include <stdio.h>

int main()
{
    int n,d,sum=0;
    printf("enetr n value : ");
    scanf("%d",&n);
    while(n>0)
    { 
        d=n%10;
        if(d%2==0)
        sum=sum+d;
        n=n/10;
    }
    printf("sum of digits is %d",sum);
}