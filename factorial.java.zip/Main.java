
public class Main
{
	public static void main(String[] args) {
	    int a=3,b,fact;
	    fact=a;
	    b=a-1;
	    while(b>1)
	    {
	        fact=fact*b;
	        b--;
	    }
		System.out.println("Factorial of "+a+" is "+fact);
	}
}
