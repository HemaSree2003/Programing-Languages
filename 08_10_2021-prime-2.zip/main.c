#include <stdio.h>

int main()
{
    int n,count=0,i;
    printf("enter n value : ");
    scanf("%d",&n);
    i=2;
    while(i<=n-1)
    {
        if(n%i==0)
        count++;
        i++;
    } 
        if(count==0)
        printf("prime number");
        else
        printf("not prime number");
    return 0;
}

