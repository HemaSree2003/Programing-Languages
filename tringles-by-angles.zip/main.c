#include <stdio.h>
void main()
{
    int a,b,c;
      printf("enter a,b,c values : ");
      scanf("%d %d %d",&a,&b,&c);
    if (a+b+c==180)
      printf("traingle is formed");
    else 
      printf("triangle is not formed");
}
