#include<stdio.h>
void main()
{
    int x;
      printf("enter the age : ");
      scanf("%d",&x);
    if (x>=18)
      printf("eligible");
    else 
      printf("not eligible");
}
